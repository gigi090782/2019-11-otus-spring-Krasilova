package ru.krasilova.otus.spring.homework12.exceptions;

public class NotFoundException extends RuntimeException{

    public NotFoundException() {
    }
}
